const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Simulated database
const usersDb = {};

// Secret key for JWT
const SECRET_KEY = "your_secret_key_here";

// Middleware for authenticating and authorizing based on roles
function authenticateToken(req, res, next) {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Access Denied: No token provided.' });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ error: 'Invalid or expired token.' });
        req.user = user;
        next();
    });
}

function authorizeRoles(...allowedRoles) {
    return (req, res, next) => {
        if (!allowedRoles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Access Denied: Insufficient permissions.' });
        }
        next();
    };
}

// Register a new user
app.post('/register', async (req, res) => {
    const { username, password, role } = req.body;

    if (!username || !password || !role) {
        return res.status(400).json({ error: 'Username, password, and role are required.' });
    }

    if (usersDb[username]) {
        return res.status(400).json({ error: 'Username already exists.' });
    }

    if (!['Admin', 'User', 'Moderator'].includes(role)) {
        return res.status(400).json({ error: 'Invalid role.' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        usersDb[username] = { password: hashedPassword, role };
        res.status(201).json({ message: 'User registered successfully.' });
    } catch (err) {
        res.status(500).json({ error: 'Error registering user.' });
    }
});

// Login a user
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required.' });
    }

    const user = usersDb[username];
    if (!user) {
        return res.status(404).json({ error: 'User not found.' });
    }

    try {
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ error: 'Invalid credentials.' });
        }

        // Generate JWT token with role
        const token = jwt.sign({ username, role: user.role }, SECRET_KEY, { expiresIn: '1h' });
        res.status(200).json({ message: 'Login successful.', token });
    } catch (err) {
        res.status(500).json({ error: 'Error logging in.' });
    }
});

// Protected routes with role-based authorization

// Admin-only route
app.get('/admin', authenticateToken, authorizeRoles('Admin'), (req, res) => {
    res.status(200).json({ message: `Hello Admin ${req.user.username}, welcome to the admin panel!` });
});

// Moderator route
app.get('/moderator', authenticateToken, authorizeRoles('Moderator', 'Admin'), (req, res) => {
    res.status(200).json({ message: `Hello Moderator ${req.user.username}, you can moderate content.` });
});

// User-only route
app.get('/user', authenticateToken, authorizeRoles('User', 'Admin', 'Moderator'), (req, res) => {
    res.status(200).json({ message: `Hello ${req.user.username}, welcome to the user dashboard.` });
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
